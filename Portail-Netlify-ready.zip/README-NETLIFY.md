# Portail Bulletins — déploiement Netlify

Cette version est préparée pour Netlify :
- site public dans `public/`
- API Express dans une Netlify Function
- Firestore et Firebase Storage côté serveur
- identifiants administrateur dans les variables d'environnement
- session administrateur stateless, compatible avec les invocations serverless
- aucune clé Firebase privée n'est incluse dans ce dossier

## 1. Variables Netlify à créer

Dans Netlify : Project configuration → Environment variables.

Créer au minimum :

`FIREBASE_PROJECT_ID`
= `bulletins-8dd4d`

`FIREBASE_STORAGE_BUCKET`
= `bulletins-8dd4d.firebasestorage.app`

`FIREBASE_SERVICE_ACCOUNT_JSON`
= le contenu COMPLET du nouveau fichier JSON du compte de service Firebase.

`ADMIN_IDENTIFIANT`
= `admin`

`ADMIN_MOT_DE_PASSE`
= votre nouveau mot de passe administrateur

`ADMIN_SESSION_SECRET`
= une longue valeur aléatoire, par exemple générée localement avec Node :

`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

Les variables contenant des secrets doivent rester dans Netlify et ne doivent pas être placées dans Git. Les variables doivent être disponibles pour les Functions.

## 2. Important : clé Firebase

Le projet original contenait une clé privée de compte de service. Elle n'est volontairement PAS incluse dans cette version Netlify.

Comme cette clé a été utilisée dans l'ancienne archive, il est fortement recommandé de la révoquer et d'en générer une nouvelle dans Firebase/Google Cloud avant la mise en ligne.

## 3. Déploiement

Décompresser ce dossier puis :
1. créer un nouveau site Netlify ;
2. choisir ce dossier comme dossier du projet ;
3. laisser Netlify détecter `netlify.toml` ;
4. ajouter les variables ci-dessus ;
5. lancer le déploiement.

Après déploiement :
- `/` : consultation publique
- `/connexion-admin` : connexion administration
- `/administration` : administration protégée
- `/api/health` : test technique

## 4. Données existantes

La configuration utilise toujours le projet Firebase `bulletins-8dd4d`. Elle ne crée pas une nouvelle base.

La recherche publique a été rendue compatible avec les anciens agents qui ne possèdent pas encore `nomNormalise`.

Les nouveaux agents enregistrent désormais `nomNormalise`, et le contrôle d'unicité du mécano reste actif.

## 5. Upload des bulletins

La taille maximale des fichiers est fixée à 5 Mo pour rester adaptée au fonctionnement serverless Netlify. Les formats autorisés restent PDF, JPG/JPEG et PNG.
