import express from 'express';
import { firestore } from '../firebase.js';

const routes = express.Router();

function normaliser(valeur) {
    return String(valeur || '')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, ' ');
}

routes.get('/test', (req, res) => {
    res.json({
        success: true,
        message: 'API publique opérationnelle'
    });
});

routes.get('/recherche', async (req, res) => {
    try {
        const nom = normaliser(req.query.nom);
        const mecano = String(req.query.mecano || '')
            .trim()
            .toUpperCase()
            .replace(/\s+/g, '');

        if (!nom || !mecano) {
            return res.status(400).json({
                success: false,
                message: 'Le nom et le mécano sont obligatoires.'
            });
        }

        // Recherche compatible avec les anciens agents qui n'ont pas
        // forcément le champ nomNormalise.
        const snapshot = await firestore
            .collection('agents')
            .get();

        const correspondants = snapshot.docs.filter(doc => {
            const agent = doc.data();
            const nomAgent = normaliser(
                agent.nomNormalise || agent.nom
            );
            const mecanoAgent = String(
                agent.mecanoNormalise || agent.mecano || ''
            )
                .trim()
                .toUpperCase()
                .replace(/\s+/g, '');

            return nomAgent === nom && mecanoAgent === mecano;
        });

        if (!correspondants.length) {
            return res.json({
                success: true,
                agent: null,
                message: 'Aucun agent trouvé.'
            });
        }

        const agentDoc = correspondants[0];
        const agent = {
            id: agentDoc.id,
            ...agentDoc.data()
        };

        const bulletinsSnapshot = await firestore
            .collection('bulletins')
            .where('agentId', '==', agentDoc.id)
            .get();

        const bulletins = bulletinsSnapshot.docs
            .map(doc => ({
                id: doc.id,
                ...doc.data()
            }))
            .sort(
                (a, b) =>
                    Number(b.annee || 0) -
                    Number(a.annee || 0)
            );

        delete agent.nomNormalise;
        delete agent.mecanoNormalise;

        return res.json({
            success: true,
            agent,
            bulletins
        });

    } catch (error) {
        console.error('Erreur recherche agent :', error);

        return res.status(500).json({
            success: false,
            message: 'Erreur lors de la recherche.'
        });
    }
});

export default routes;
