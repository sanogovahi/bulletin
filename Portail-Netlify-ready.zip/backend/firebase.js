import admin from 'firebase-admin';
import fs from 'fs';
import path from 'path';

function chargerCompteService() {
    const jsonEnv = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

    if (jsonEnv) {
        try {
            return JSON.parse(jsonEnv);
        } catch (error) {
            throw new Error(
                'FIREBASE_SERVICE_ACCOUNT_JSON est présent mais n’est pas un JSON valide.'
            );
        }
    }

    // Compatibilité locale uniquement : le fichier peut exister sur le PC,
    // mais il n'est pas inclus dans le déploiement Netlify.
    const cheminLocal = path.join(
        process.cwd(),
        'firebase-service-account.json'
    );

    if (fs.existsSync(cheminLocal)) {
        return JSON.parse(
            fs.readFileSync(cheminLocal, 'utf8')
        );
    }

    throw new Error(
        'Configuration Firebase absente. Définissez FIREBASE_SERVICE_ACCOUNT_JSON dans les variables Netlify.'
    );
}

const compteService = chargerCompteService();

const projectId =
    process.env.FIREBASE_PROJECT_ID ||
    compteService.project_id;

const storageBucket =
    process.env.FIREBASE_STORAGE_BUCKET ||
    `${projectId}.firebasestorage.app`;

if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(compteService),
        projectId,
        storageBucket
    });
}

export const firestore = admin.firestore();
export const auth = admin.auth();
export const bucket = admin.storage().bucket();

console.log('✅ Firebase connecté :', projectId);
console.log('🪣 Storage :', bucket.name);
