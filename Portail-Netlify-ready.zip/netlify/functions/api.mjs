import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';
import serverless from 'serverless-http';

import '../../backend/firebase.js';
import publicRoutes from '../../backend/routes/public.js';
import adminRoutes from '../../backend/routes/admin.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.resolve(__dirname, '../../public');

const app = express();

const ADMIN_IDENTIFIANT = process.env.ADMIN_IDENTIFIANT;
const ADMIN_MOT_DE_PASSE = process.env.ADMIN_MOT_DE_PASSE;
const ADMIN_SESSION_SECRET = process.env.ADMIN_SESSION_SECRET;

if (!ADMIN_IDENTIFIANT || !ADMIN_MOT_DE_PASSE || !ADMIN_SESSION_SECRET) {
    console.error(
        'Configuration admin incomplète. Définissez ADMIN_IDENTIFIANT, ADMIN_MOT_DE_PASSE et ADMIN_SESSION_SECRET dans Netlify.'
    );
}

app.use(cors({
    origin: true,
    credentials: true
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({
    extended: true,
    limit: '1mb'
}));

function creerSignature(instant) {
    return crypto
        .createHmac('sha256', ADMIN_SESSION_SECRET || '')
        .update(String(instant))
        .digest('hex');
}

function creerSessionAdmin() {
    const instant = Date.now();
    return `${instant}.${creerSignature(instant)}`;
}

function obtenirCookie(req, nom) {
    const cookies = req.headers.cookie || '';

    const trouve = cookies
        .split(';')
        .map(item => item.trim())
        .find(item => item.startsWith(`${nom}=`));

    if (!trouve) return null;

    return decodeURIComponent(
        trouve.slice(nom.length + 1)
    );
}

function estAuthentifie(req) {
    const token = obtenirCookie(req, 'admin_session');

    if (!token || !ADMIN_SESSION_SECRET) {
        return false;
    }

    const [instant, signature] = token.split('.');

    if (!instant || !signature || !/^\d+$/.test(instant)) {
        return false;
    }

    // Session valide 8 heures.
    const age = Date.now() - Number(instant);

    if (age < 0 || age > 8 * 60 * 60 * 1000) {
        return false;
    }

    const attendu = creerSignature(instant);

    try {
        return crypto.timingSafeEqual(
            Buffer.from(signature),
            Buffer.from(attendu)
        );
    } catch {
        return false;
    }
}

function cookieSession(token) {
    const secure = process.env.NODE_ENV === 'production'
        ? ' Secure;'
        : '';

    return [
        `admin_session=${encodeURIComponent(token)}`,
        'HttpOnly',
        'Path=/',
        'SameSite=Lax',
        'Max-Age=28800',
        secure
    ].join('; ');
}

function cookieSuppression() {
    const secure = process.env.NODE_ENV === 'production'
        ? ' Secure;'
        : '';

    return [
        'admin_session=',
        'HttpOnly',
        'Path=/',
        'SameSite=Lax',
        'Max-Age=0',
        secure
    ].join('; ');
}

/* API publique */
app.use('/api/public', publicRoutes);

/* Connexion administrateur */
app.post('/api/admin-login', (req, res) => {
    if (!ADMIN_IDENTIFIANT || !ADMIN_MOT_DE_PASSE || !ADMIN_SESSION_SECRET) {
        return res.status(500).json({
            success: false,
            message: 'Configuration administrateur absente sur le serveur.'
        });
    }

    const {
        identifiant,
        motDePasse
    } = req.body || {};

    if (!identifiant || !motDePasse) {
        return res.status(400).json({
            success: false,
            message: 'Veuillez renseigner l’identifiant et le mot de passe.'
        });
    }

    if (
        identifiant !== ADMIN_IDENTIFIANT ||
        motDePasse !== ADMIN_MOT_DE_PASSE
    ) {
        return res.status(401).json({
            success: false,
            message: 'Identifiant ou mot de passe incorrect.'
        });
    }

    const token = creerSessionAdmin();

    res.setHeader(
        'Set-Cookie',
        cookieSession(token)
    );

    return res.json({
        success: true,
        message: 'Connexion administrateur réussie.'
    });
});

app.get('/api/admin-session', (req, res) => {
    if (!estAuthentifie(req)) {
        return res.status(401).json({
            success: false,
            message: 'Session administrateur inexistante.'
        });
    }

    return res.json({
        success: true,
        authentifie: true
    });
});

app.post('/api/admin-logout', (req, res) => {
    res.setHeader(
        'Set-Cookie',
        cookieSuppression()
    );

    return res.json({
        success: true,
        message: 'Déconnexion réussie.'
    });
});

/* Protection de toutes les routes admin */
app.use(
    '/api/admin',
    (req, res, next) => {
        if (!estAuthentifie(req)) {
            return res.status(401).json({
                success: false,
                message: 'Accès administrateur non autorisé.'
            });
        }

        next();
    },
    adminRoutes
);

/* Page administration protégée */
app.get('/administration', (req, res) => {
    if (!estAuthentifie(req)) {
        return res.redirect('/connexion-admin.html');
    }

    return res.sendFile(
        path.join(publicDir, 'administration.html')
    );
});

/* Santé de l'API */
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        service: 'Portail Bulletins',
        firebase: Boolean(process.env.FIREBASE_SERVICE_ACCOUNT_JSON),
        adminConfigured: Boolean(
            ADMIN_IDENTIFIANT &&
            ADMIN_MOT_DE_PASSE &&
            ADMIN_SESSION_SECRET
        )
    });
});

export const handler = serverless(app);
